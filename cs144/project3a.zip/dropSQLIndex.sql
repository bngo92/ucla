DROP INDEX buyPriceIndex ON Item; 
DROP INDEX endTimeIndex ON Item;
DROP INDEX sellerIndex ON Item;
