CREATE INDEX buyPriceIndex ON Item(Buy_Price);
CREATE INDEX endTimeIndex ON Item(Ends);
CREATE INDEX sellerIndex ON Item(Seller);
