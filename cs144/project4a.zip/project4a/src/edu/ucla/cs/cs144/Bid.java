package edu.ucla.cs.cs144;

import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * User: Rachel Fang
 * Date: 11/17/13
 * Time: 9:31 PM
 * To change this template use File | Settings | File Templates.
 */
public class Bid {
    public String bidder;
    public String bidder_rating;
    public String amount;
    public String timeStr;
    public String location;
    public String country;
    public Date datetime;

}